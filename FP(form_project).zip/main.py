from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit_form', methods=['POST'])
def submit_form():
    name = request.form['name']
    email = request.form['email']
    message = request.form['message']
    
    # Verileri form.txt dosyasına kaydet
    with open('form.txt', 'a') as f:
        f.write(f"Name: {name}\n")
        f.write(f"Email: {email}\n")
        f.write(f"Message: {message}\n")
        f.write("----------\n")
    
    return render_template('form_result.html', name=name, email=email, message=message)

if __name__ == '__main__':
    app.run(debug=True)
